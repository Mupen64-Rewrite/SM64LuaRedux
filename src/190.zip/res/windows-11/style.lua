return {
    name = 'Windows 11',
    theme = get_base_style()
}

return {
    name = 'Windows 10',
    theme = get_base_style()
}
